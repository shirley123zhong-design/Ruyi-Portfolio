"""Build EY DuPont analysis tables from the source .xls workbook."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "EY_DuPont.xls"
OUT_XLSX = ROOT / "EY_DuPont_Model.xlsx"
OUT_PARQUET = ROOT / "EY_DuPont_Ratios.parquet"


def _safe_div(num: pd.Series, den: pd.Series) -> pd.Series:
    den = den.replace(0, np.nan)
    return num / den


def load_source(path: Path = SOURCE) -> tuple[pd.DataFrame, pd.DataFrame]:
    bs = pd.read_excel(path, sheet_name="Balance Sheet Data")
    inc = pd.read_excel(path, sheet_name="Income Statement Data")
    return bs, inc


def build_ratios(bs: pd.DataFrame, inc: pd.DataFrame) -> pd.DataFrame:
    keep_inc = inc[["Ticker", "Year", "Net Revenues", "Net Income"]].copy()
    matched = bs.merge(keep_inc, on=["Ticker", "Year"], how="inner")

    matched["ROE"] = _safe_div(matched["Net Income"], matched["Total Shareholder Equity"])
    matched["Profit Margin"] = _safe_div(matched["Net Income"], matched["Net Revenues"])
    matched["Asset Turnover"] = _safe_div(matched["Net Revenues"], matched["Total Assets"])
    matched["Financial Leverage"] = _safe_div(
        matched["Total Assets"], matched["Total Shareholder Equity"]
    )
    # DuPont identity check (informational)
    matched["ROE_DuPont_Check"] = (
        matched["Profit Margin"] * matched["Asset Turnover"] * matched["Financial Leverage"]
    )

    cols = [
        "Ticker",
        "Name",
        "Industry",
        "Year",
        "Total Assets",
        "Total Shareholder Equity",
        "Net Revenues",
        "Net Income",
        "ROE",
        "Profit Margin",
        "Asset Turnover",
        "Financial Leverage",
        "ROE_DuPont_Check",
    ]
    return matched[cols].sort_values(["Industry", "Name", "Year"]).reset_index(drop=True)


def build_company_yoy(ratios: pd.DataFrame) -> pd.DataFrame:
    """Wide company view for 2014 vs 2015 and % change — mirrors analyse_3."""
    base = ratios[ratios["Year"].isin([2014, 2015])].copy()
    metrics = ["ROE", "Profit Margin", "Asset Turnover", "Financial Leverage"]
    wide = base.pivot_table(
        index=["Ticker", "Name", "Industry"],
        columns="Year",
        values=metrics,
        aggfunc="first",
    )
    wide.columns = [f"{m} {y}" for m, y in wide.columns]
    wide = wide.reset_index()
    for m in metrics:
        c14, c15 = f"{m} 2014", f"{m} 2015"
        if c14 in wide.columns and c15 in wide.columns:
            wide[f"{m} % change"] = _safe_div(wide[c15] - wide[c14], wide[c14].abs())
    return wide


def build_industry_medians(ratios: pd.DataFrame) -> pd.DataFrame:
    metrics = ["ROE", "Profit Margin", "Asset Turnover", "Financial Leverage"]
    med = (
        ratios.groupby(["Industry", "Year"], as_index=False)[metrics]
        .median()
        .sort_values(["Industry", "Year"])
    )
    return med


def build_data_accuracy(bs: pd.DataFrame, ratios: pd.DataFrame) -> pd.DataFrame:
    matched_assets = float(ratios["Total Assets"].sum())
    bs_assets = float(bs["Total Assets"].sum())
    sales_2013 = (
        ratios.loc[ratios["Year"] == 2013]
        .groupby("Industry", as_index=False)["Net Revenues"]
        .sum()
        .rename(columns={"Net Revenues": "Total Sales 2013"})
    )
    companies = (
        ratios.groupby("Industry", as_index=False)["Ticker"]
        .nunique()
        .rename(columns={"Ticker": "Companies"})
    )
    summary = pd.DataFrame(
        [
            {
                "Metric": "Total Assets — Balance Sheet only",
                "Value": bs_assets,
            },
            {
                "Metric": "Total Assets — Matching BS & IS",
                "Value": matched_assets,
            },
            {
                "Metric": "Companies — Balance Sheet",
                "Value": bs["Name"].nunique(),
            },
            {
                "Metric": "Companies — Matching BS & IS",
                "Value": ratios["Ticker"].nunique(),
            },
            {
                "Metric": "Asset difference (BS - matched)",
                "Value": bs_assets - matched_assets,
            },
        ]
    )
    return summary, sales_2013, companies


def top_revenue_companies(ratios: pd.DataFrame, n: int = 5) -> pd.DataFrame:
    tot = (
        ratios.groupby(["Ticker", "Name"], as_index=False)["Net Revenues"]
        .sum()
        .sort_values("Net Revenues", ascending=False)
        .head(n)
    )
    return tot


def best_roe_by_industry(ratios: pd.DataFrame, year: int = 2015) -> pd.DataFrame:
    y = ratios[ratios["Year"] == year]
    idx = y.groupby("Industry")["ROE"].idxmax()
    return y.loc[idx, ["Industry", "Name", "Ticker", "ROE", "Profit Margin", "Asset Turnover", "Financial Leverage"]].sort_values("Industry")


def brick_wall_companies(ratios: pd.DataFrame, year: int = 2015, n: int = 3) -> pd.DataFrame:
    y = ratios[ratios["Year"] == year]
    return (
        y[y["Profit Margin"] < 0]
        .nlargest(n, "Asset Turnover")[
            ["Name", "Industry", "Profit Margin", "Asset Turnover", "ROE", "Financial Leverage"]
        ]
        .reset_index(drop=True)
    )


def export_all(path: Path = SOURCE) -> dict[str, pd.DataFrame]:
    bs, inc = load_source(path)
    ratios = build_ratios(bs, inc)
    yoy = build_company_yoy(ratios)
    industry = build_industry_medians(ratios)
    accuracy, sales_2013, companies = build_data_accuracy(bs, ratios)
    top_rev = top_revenue_companies(ratios)
    best_roe = best_roe_by_industry(ratios)
    brick = brick_wall_companies(ratios)

    with pd.ExcelWriter(OUT_XLSX, engine="openpyxl") as writer:
        ratios.to_excel(writer, sheet_name="DuPont_Ratios", index=False)
        yoy.to_excel(writer, sheet_name="Company_YoY_2014_2015", index=False)
        industry.to_excel(writer, sheet_name="Industry_Medians", index=False)
        accuracy.to_excel(writer, sheet_name="Data_Accuracy", index=False)
        sales_2013.to_excel(writer, sheet_name="Industry_Sales_2013", index=False)
        companies.to_excel(writer, sheet_name="Industry_Companies", index=False)
        top_rev.to_excel(writer, sheet_name="Top_Revenue_Companies", index=False)
        best_roe.to_excel(writer, sheet_name="Best_ROE_2015", index=False)
        brick.to_excel(writer, sheet_name="Brick_Wall_2015", index=False)
        bs.to_excel(writer, sheet_name="Balance_Sheet_Raw", index=False)
        inc.to_excel(writer, sheet_name="Income_Statement_Raw", index=False)

    ratios.to_parquet(OUT_PARQUET, index=False)

    return {
        "ratios": ratios,
        "yoy": yoy,
        "industry": industry,
        "accuracy": accuracy,
        "sales_2013": sales_2013,
        "companies": companies,
        "top_rev": top_rev,
        "best_roe": best_roe,
        "brick": brick,
    }


if __name__ == "__main__":
    tables = export_all()
    r = tables["ratios"]
    print(f"Wrote {OUT_XLSX}")
    print(f"Wrote {OUT_PARQUET}")
    print(f"Matched companies: {r['Ticker'].nunique()} | rows: {len(r)}")
    print(tables["accuracy"].to_string(index=False))
